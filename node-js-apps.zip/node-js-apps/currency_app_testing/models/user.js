var mongoose = require('mongoose');
var userSchema = mongoose.Schema({
    username : {type : string , required : true,unique : true},
    password : {type : string,required : true},
    createdAt : {type : Date,default : Date.now},
    displayName : string,
    bio : string
});

userSchema.methods.name = function(){
    return this.displayName || this.username;
};

