var net = require('net');

net.createServer(function(socket){
    socket.once('data',function(data){
         // console.log(data);
        socket.write(data+'\n');
    })
}).listen(3001);

console.log('TCP server is running!');