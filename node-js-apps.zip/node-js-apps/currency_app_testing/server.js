var http = require('http');
var express = require('express');
var currency = require('./lib/currency');
var app = express();



http.createServer(function(req,res){

     res.writeHead(200, {'Content-Type': 'text/plain'});
     var canadianToUS = currency.canadianToUS(100);
     var  USToCanadian = currency.USToCanadian(100);

     var output = {
        'canadianToUS' : canadianToUS,
        'USToCanadian' : USToCanadian
     };

 res.end(JSON.stringify(output)+'\n');

}).listen(3000);

console.log('application started!');