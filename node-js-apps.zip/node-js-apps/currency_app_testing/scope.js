function asyncFunction(callBack){
    setTimeout(callBack,200);
}

var color = 'Blue';


 console.log('The Color is : ' + color);

(function(color){
    asyncFunction(function(){
        console.log('The Color is (A) : ' + color);
    })
})(color);

color = 'Green';

 console.log('The Color is : ' + color);