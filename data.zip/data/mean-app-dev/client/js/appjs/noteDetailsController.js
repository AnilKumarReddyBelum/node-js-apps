noteApp.controller("noteDetailsController", function ($scope, noteService) {

    $scope.filteredNotes = []
        , $scope.currentPage = 1
        , $scope.numPerPage = 10
        , $scope.maxSize = 5;

    $scope.notes = [];

    $scope.GetNotesList = function GetNotesList() {
        noteService.getAllNotes().success(function (notes) {
            $scope.notes = notes;
            $scope.$watch('currentPage + numPerPage', function () {
                var begin = (($scope.currentPage - 1) * $scope.numPerPage);
                var end = begin + $scope.numPerPage;
                $scope.filteredNotes = $scope.notes.slice(begin, end);
            });

        }).error(function () {
            alert('Error in getting records');
        });
    };




}); 