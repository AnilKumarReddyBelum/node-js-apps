noteApp.controller("noteController", function ($scope, noteService) {



    GetNotesList();
    $scope.notes = [];


    $scope.AddOrUpdate = function (note) {
        if (note != null && note._id != null && note._id != undefined) {
            // alert('coming to update');
            $scope.UpdateNote(note);
        } else {
            //alert('coming to add');
            $scope.AddNote(note);
        }
    }


    $scope.note = {
        name: undefined,
        type: undefined,
        desc: undefined,
        _id: undefined
    }

    //To Get All Records  
    function GetNotesList() {
        noteService.getAllNotes().success(function (notes) {
            $scope.notes = notes;
        }).error(function () {
            alert('Error in getting records');
        });
    }






    $scope.EditNote = function (note) {
        $scope.note.name = note.name;
        $scope.note.type = note.type;
        $scope.note.desc = note.desc;
        $scope.note._id = note._id;
    }

    $scope.Reset = function () {
        $scope.note.name = undefined;
        $scope.note.type = undefined;
        $scope.note.desc = undefined;
        $scope.note._id = undefined;
        console.log('reset done');
    }

    function reset() {
        $scope.note.name = undefined;
        $scope.note.type = undefined;
        $scope.note.desc = undefined;
        $scope.note._id = undefined;
        console.log('reset done');
    }


    // Adding New Note record  
    $scope.AddNote = function (note) {
        noteService.AddNote(note).success(function (output) {
            alert('Notes Created Successfully!');
            $scope.notes.push(output);
            reset();
        }, function () {
            alert('Error in adding record');
        });
    }


    // Deleting record.  
    $scope.DeleteNote = function (note,index) {
        var retval = noteService.DeleteNote(note).success(function (msg) {
            //alert('msg==>' + msg);
            $scope.notes.splice(index, 1);
            reset();
        }).error(function () {
            alert('Oops! something went wrong.');
        });
    }




    // Updating Records  
    $scope.UpdateNote = function (tbl_note) {
        var RetValData = noteService.UpdateNote(tbl_note).success(function (note) {

            // alert('successfully updated -> ' + note._id);

          for(var i=0; i < $scope.notes.length; i++){
                var currentNote = $scope.notes[i];
                if(currentNote._id == note._id){
                    $scope.notes[i] = note;
                    break;
                }
          }

            reset();
        }, function () {
            alert('Error in adding record');
        });
    }
}); 