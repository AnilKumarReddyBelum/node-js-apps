var noteApp = angular.module('noteApp', ['ngRoute', 'ui.bootstrap']);
noteApp.controller('noteHomeController', function ($scope) { });
