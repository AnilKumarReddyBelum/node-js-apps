noteApp.service('noteService', function ($http) {



    //Get the all Notes information
    this.getAllNotes = function () {
        return $http.get('/notes');
    };


    //Create a new Note over here
    this.AddNote = function (newNote) {
        return $http({
            method: 'put',
            url: '/addNote',
            data: JSON.stringify(newNote),
            dateType: 'json'
        });
    };

    //Update the existing Note
    this.UpdateNote = function (note) {
        return $http({
            method: 'post',
            url: '/updateNote',
            data: JSON.stringify(note),
            dateType: 'json'
        });
    }


    //Delete the existing Note by _id
    this.DeleteNote = function (note) {
        return $http.delete('/deleteNote/' + note._id);
    }



});
