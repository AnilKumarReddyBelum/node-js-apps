var mongoose = require('../config/db');

var noteSchema = new mongoose.Schema({
    name: { type: String, default: '' },
    type: { type: String, default: '' },
    desc: { type: String, default: '' },
    time: { type: Date, default: new Date() }
});

module.exports = mongoose.model('Note', noteSchema);

