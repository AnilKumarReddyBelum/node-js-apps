var myApp = angular.module('myApp', ['ngRoute']);

myApp.config(function ($routeProvider) {
  $routeProvider
    .when('/', {
      templateUrl: 'partials/home.html',
      access: { restricted: true }
    })
    .when('/login', {
      templateUrl: 'partials/login.html',
      controller: 'loginController',
      access: { restricted: false }
    })
    .when('/logout', {
      controller: 'logoutController',
      access: { restricted: true }
    })
    .when('/register', {
      templateUrl: 'partials/register.html',
      controller: 'registerController',
      access: { restricted: false }
    })
    .when('/one', {
      template: '<h1>This is page one!</h1> <a href="http://localhost:3000/#/">Back</a>',
      access: { restricted: true }
    })
    .when('/two', {
      template: '<h1>This is page two!</h1> <a href="http://localhost:3000/#/">Back</a>',
      access: { restricted: false }
    })
    .otherwise({
      redirectTo: '/'
    });
});

myApp.run(function ($rootScope, $location, $route, AuthService) {
  $rootScope.$on('$routeChangeStart',
    function (event, next, current) {
      AuthService.getUserStatus()
        .then(function () {

          var restrictedVal = undefined;
          if (next.access != undefined && next.access.restricted != undefined) {
            restrictedVal = next.access.restricted;
          }

          if (restrictedVal && !AuthService.isLoggedIn()) {
            $location.path('/login');
            $route.reload();
          }
        });
    });
});